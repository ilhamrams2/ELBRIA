<div class="col-md-12">
<div class="container">
        <?php 
            if ($_GET['ubah']=='ubah-kamar') {
                $sqle = $con->query("SELECT*FROM tb_kamar WHERE id_kamar='$_GET[idt]'");
                $tamp = $sqle->fetch_array();
                $ae = $tamp['tipe_kamar'];
        ?>
        <br>
        <h4>UBAH DATA KAMAR</h4>
        <br>
        <form action="" method="POST" enctype="multipart/form-data">
        <div class="form-row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="pwd">Nama Kamar</label>
                    <select type="text" class="form-control"  name="nama">
                        <?php 
                            $tipe = $con->query("SELECT*FROM nama_kamar");
                            while ($tipetam = $tipe->fetch_array()) {
                        ?>
                            <option value='<?=$tipetam[nama_kamar]?>'<?php if($tipetam[nama_kamar]==$ae){ echo 'selected';} ?> ><?=$tipetam[nama_kamar]?></option>
                        <?php
                            } 
                         ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="pwd">Tipe Kamar</label>
                    <select type="text" class="form-control"  name="tipe">
                        <?php 
                            $tipe = $con->query("SELECT*FROM tipe_kamar");
                            while ($tipetam = $tipe->fetch_array()) {
                        ?>
                            <option value='<?=$tipetam[tipe_kamar]?>'<?php if($tipetam[tipe_kamar]==$ae){ echo 'selected';} ?> ><?=$tipetam[tipe_kamar]?></option>
                        <?php
                            } 
                         ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="pwd">Harga Kamar</label>
                    <input type="number" class="form-control"  name="harga" value="<?=$tamp['harga_kamar']?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="pwd">Gambar Kamar</label>
                    <input type="file" class="form-control"  name="gbr">
                  </div>
               </div>
                 <div class="col-md-3">
                  <div class="form-group">
                    <img class="img-fluid" src="../gambar/<?=$tamp['gambar_kamar']?>" width="150">
                  </div>
                </div>
               <div class="col-md-9">
                  <div class="form-group">
                    <label for="pwd">Desk Kamar</label>
                    <textarea type="text" class="form-control"  name="desk"><?=$tamp['desk_kamar']?></textarea>
                  </div>
               </div>
               <div class="col-md-12">
                  <input type="submit" class="btn btn-primary" name="btnedit"></input>
              </div>
        </div>
        <?php
        if (isset($_POST['btnedit'])) {
            $name = $_FILES['gbr']['name'];
            $file = $_FILES['gbr']['tmp_name'];
            move_uploaded_file($file,"../gambar/$name");
            if (empty($_FILES['gbr']['name'])) {
               $sqli = $con->query("UPDATE tb_kamar SET nama_kamar='$_POST[nama]', tipe_kamar='$_POST[tipe]', harga_kamar='$_POST[harga]', desk_kamar='$_POST[desk]' WHERE id_kamar='$_GET[idt]'");  
            }else{
                 $sqli = $con->query("UPDATE tb_kamar SET nama_kamar='$_POST[nama]', tipe_kamar='$_POST[tipe]', harga_kamar='$_POST[harga]', desk_kamar='$_POST[desk]', gambar_kamar='$name' WHERE id_kamar='$_GET[idt]'");
            }
           
            if ($sqli) {
                echo "Data masuk";
            }else{
                echo "data tidak masuk";
            }
        }

         ?>
    </form>

        <?php
            }else{
         ?>
    <br>
    <h4>INPUT DATA KAMAR</h4>
    <br>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="form-row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="pwd">Tipe Kamar</label>
                    <select type="text" class="form-control"  name="nama">
                        <?php 
                            $tipe = $con->query("SELECT*FROM nama_kamar");
                            while ($tipetam = $tipe->fetch_array()) {
                        ?>
                            <option value="<?=$tipetam['nama_kamar']?>"><?=$tipetam['nama_kamar']?></option>
                        <?php
                            } 
                         ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="pwd">Tipe Kamar</label>
                    <select type="text" class="form-control"  name="tipe">
                        <?php 
                            $tipe = $con->query("SELECT*FROM tipe_kamar");
                            while ($tipetam = $tipe->fetch_array()) {
                        ?>
                            <option value="<?=$tipetam['tipe_kamar']?>"><?=$tipetam['tipe_kamar']?></option>
                        <?php
                            } 
                         ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="pwd">Harga Kamar</label>
                    <input type="number" class="form-control"  name="harga">
                  </div>
                </div>
               <div class="col-md-6">
                  <div class="form-group">
                    <label for="pwd">Gambar Kamar</label>
                    <input type="file" class="form-control"  name="gbr">
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="form-group">
                    <label for="pwd">Desk Kamar</label>
                    <textarea type="text" class="form-control"  name="desk"></textarea>
                  </div>
               </div>
               <div class="col-md-12">
                  <input type="submit" class="btn btn-primary" name="btn"></input>
              </div>
        </div>
        <?php
        if (isset($_POST['btn'])) {
            $name = $_FILES['gbr']['name'];
            $file = $_FILES['gbr']['tmp_name'];
            move_uploaded_file($file,"../gambar/$name");
            $sqli = $con->query("INSERT INTO tb_kamar VALUES('','$_POST[nama]','$_POST[tipe]','$_POST[harga]','$_POST[desk]','$name')");
            if ($sqli) {
                echo "Data masuk";
            }else{
                echo "data tidak masuk";
            }
        }

         ?>
    </form>
<?php 
}
 ?>
</div>
<div class="col-md-12">
<div class="container">
  <br>
  <br>
  <h4>DATA KAMAR</h4>
<br>
  <table id="example" class="table table-striped table-bordered" style="width:100%; font-size: 14px;">
        <thead>
            <tr>
                <th>No</th>
                <th>Id kamar</th>
                <th>Jumlah Kamar</th>
                <th>Nama Kamar</th>
                <th>Harga Kamar</th>
                <th>Deskripsi</th>
                <th>Gambar kamar</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
             <?php 
            $no = 0;
            $sql = $con->query("SELECT*FROM tb_kamar");
            while ($tampil = $sql->fetch_array()) {
            ?>
            <tr>
                <td><?=$no=$no+1?></td>
                <td><?=$tampil['id_kamar']?></td>
                <td><?=$tampil['nama_kamar']?></td>
                <td><?=$tampil['tipe_kamar']?></td>
                <td><?=$tampil['harga_kamar']?></td>
                <td><?=$tampil['desk_kamar']?></td>
                <td><img src="../gambar/<?=$tampil['gambar_kamar']?>" class="img-fluid" width="100"></td>
                <td style="text-align: center; font-size: 16px; margin: auto;"><a href="?page=kamar&ubah=ubah-kamar&idt=<?=$tampil['id_kamar']?>"><i class="fa-solid fa-pen-to-square"></i></a> | <a href="?page=kamar&hapus=hapus-kamar&idt=<?=$tampil['id_kamar']?>"><i class="fa-solid fa-trash-can"></i></a></td>
            </tr>
        <?php 
            }
            if ($_GET['hapus']=='hapus-kamar') {
                $sqlh = $con->query("DELETE FROM tb_kamar WHERE id_kamar='$_GET[idt]'");
            if ($sqlh) {
                echo "<script>document.location.href='?page=kamar';</script>";
            }else{
                echo "GAGAL MENGHAPUS";
            }
            }
        ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Id kamar</th>
                <th>Jumlah Kamar</th>
                <th>Nama Kamar</th>
                <th>Harga Kamar</th>
                <th>Deskripsi</th>
                <th>Gambar kamar</th>
                <th>Aksi</th>
            </tr>
        </tfoot>
    </table>
</div>
</div>